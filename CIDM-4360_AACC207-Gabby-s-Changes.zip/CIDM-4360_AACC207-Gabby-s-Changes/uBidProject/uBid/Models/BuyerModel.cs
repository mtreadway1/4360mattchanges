using System;

namespace uBid.Models
{
    public class BuyerModel : UserModel
    {
        public BuyerModel()
        {
            //constructor
        }
        #region "Functions"
        // public override void editAccountInfo()
        // {
        //     //code
        // }
        public void createBid()
        {
            //code 
        }
        #endregion
    }
}