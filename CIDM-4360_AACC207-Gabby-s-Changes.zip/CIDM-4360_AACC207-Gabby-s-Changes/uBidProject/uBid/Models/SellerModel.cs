using System; 

namespace uBid.Models
{
    public class SellerModel: UserModel
    {
        public SellerModel()
        {
            //constructor
        }
        #region "Functions"
        // public override void editAccountInfo()
        // {
        //     //code
        // }
        // public void setAuctionTime()
        // {
        //     //code
        // }
        // public void setReservePrice() 
        // {
        //     //code
        // }
        // public void createItem()
        // {
        //     //code
        // }
        // public void updateItem()
        // {
        //     //code
        // }
        // public void deleteItem()
        // {
        //     //code
        // }
        #endregion
    }
}